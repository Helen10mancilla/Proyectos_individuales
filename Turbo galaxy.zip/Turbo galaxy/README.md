#  Turbo Galaxy

¡Bienvenido a Turbo Galaxy!  
Un videojuego retro-tropical de carreras espaciales donde esquivas cocos en una galaxia playera interdimensional.  
Desarrollado con amor en Python y Pygame.



## Cómo jugar

- Usa ← / → para mover tu nave espacial.
- Esquiva los cocos cósmicos que caen del cielo.
- ¡Aguanta lo más que puedas sin perder tus 3 vidas!
- Cuando se acaben las vidas, puedes reiniciar con R o salir con Q.



## 🖥️ Requisitos

- Python 3.x
- Pygame ("pip install pygame")



## ▶️ Cómo correr el juego

1. Clona el repositorio:
   bash
   git clone https://github.com/Helen10mancilla/Proyectos_individuales.git
   cd turbo-galaxy
